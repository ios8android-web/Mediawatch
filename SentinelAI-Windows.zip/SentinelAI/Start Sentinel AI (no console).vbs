Set s = CreateObject("WScript.Shell")
s.Run "powershell -NoProfile -ExecutionPolicy Bypass -File """ & CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName) & "\serve.ps1""", 0, False
