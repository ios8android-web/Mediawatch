# Sentinel AI — Windows

Runs from this folder. Nothing is installed, nothing is published, and the
files never leave your machine.

---

## Start it

Double-click **Start Sentinel AI.cmd**

A small console window appears and the app opens in its own window. Leave the
console open while you use it; closing it stops the app.

Prefer no console window? Use **Start Sentinel AI (no console).vbs** instead.
Stop it later from Task Manager (Windows PowerShell), or just restart the PC.

First run may show a Windows Firewall prompt. **Allow it on Private networks
only.** The server listens on 127.0.0.1 — your own machine — and is not
reachable from the network either way.

---

## Set it up

1. **SETUP → Keys** → paste a Groq key from console.groq.com
2. Optionally add a Gemini key from aistudio.google.com as the fallback
3. **WATCH** → adjust keywords
4. **FEED → Scan now**

---

## Pin it to the Start Menu or Taskbar

Right-click **Start Sentinel AI.cmd** → Show more options → Send to → Desktop
(create shortcut). Then right-click that shortcut → Properties → Change Icon →
Browse to `app\icon-192.png`.

Right-click the shortcut → Pin to Start.

---

## Updating

Replace `index.html` and `sw.js` inside the `app` folder with newer versions.
The local server sends `no-store`, so a new build is picked up the moment you
restart it — none of the cache trouble the phone version has.

---

## Worth knowing

- **This copy is separate from your phone.** Keywords, keys and saved articles
  live in the browser profile on this machine. Nothing syncs between devices.
  Two installs means two independent watchlists.
- **It still needs the internet** to scan. Only the app itself is local; the
  news sources and the summarisation engine are not.
- **Nothing is published.** Unlike the phone version, which is served from a
  public GitHub repository, this folder is yours alone. If keeping your
  keyword list off a public URL matters, this is the better copy to use.
- **Windows can refresh in the background** where iOS cannot, if you later
  install it as an Edge app rather than running it from this folder.

---

## If it does not start

| Symptom | Cause | Fix |
|---|---|---|
| Window flashes and closes | PowerShell blocked by policy | Right-click the .cmd → Run as administrator, once |
| "No free port found" | Ports 8731-8760 all busy | Close other local servers and retry |
| Opens in a normal browser tab | Edge and Chrome not found | Harmless — it works the same way |
| Blank window | Files missing from `app` | Confirm index.html, sw.js, manifest.json and the four icons are present |
