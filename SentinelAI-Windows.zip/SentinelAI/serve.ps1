# Sentinel AI - local launcher for Windows
# Serves the app from this folder on 127.0.0.1 and opens it in an app window.
# Nothing is published; nothing leaves this machine except the news and
# engine requests the app itself makes.

$ErrorActionPreference = "Stop"
$root = Join-Path $PSScriptRoot "app"

if (-not (Test-Path $root)) {
    Write-Host "ERROR: 'app' folder not found next to this script." -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}

# --- find a free port ------------------------------------------------
$port = 0
foreach ($p in 8731..8760) {
    $inUse = $null -ne (Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue)
    if (-not $inUse) { $port = $p; break }
}
if ($port -eq 0) { Write-Host "No free port found." -ForegroundColor Red; Read-Host; exit 1 }

$prefix = "http://127.0.0.1:$port/"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($prefix)

try { $listener.Start() }
catch {
    Write-Host "Could not start the local server: $_" -ForegroundColor Red
    Read-Host "Press Enter to close"; exit 1
}

Write-Host ""
Write-Host "  Sentinel AI is running at $prefix" -ForegroundColor Cyan
Write-Host "  Close this window to stop it." -ForegroundColor DarkGray
Write-Host ""

# --- open in an app window (Edge, then Chrome, then default browser) --
$edge   = "$env:ProgramFiles(x86)\Microsoft\Edge\Application\msedge.exe"
$edge2  = "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
$chrome = "$env:ProgramFiles\Google\Chrome\Application\chrome.exe"
$chrome2= "$env:ProgramFiles(x86)\Google\Chrome\Application\chrome.exe"

$browser = @($edge, $edge2, $chrome, $chrome2) | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($browser) { Start-Process $browser -ArgumentList "--app=$prefix" }
else { Start-Process $prefix }

# --- serve -----------------------------------------------------------
$types = @{
    ".html" = "text/html; charset=utf-8"
    ".js"   = "text/javascript; charset=utf-8"
    ".json" = "application/manifest+json; charset=utf-8"
    ".png"  = "image/png"
    ".ico"  = "image/x-icon"
    ".css"  = "text/css; charset=utf-8"
}

while ($listener.IsListening) {
    try {
        $ctx = $listener.GetContext()
        $rel = [System.Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath).TrimStart('/')
        if ([string]::IsNullOrWhiteSpace($rel)) { $rel = "index.html" }

        # keep requests inside the app folder
        $full = [System.IO.Path]::GetFullPath((Join-Path $root $rel))
        $rootFull = [System.IO.Path]::GetFullPath($root)
        if (-not $full.StartsWith($rootFull)) {
            $ctx.Response.StatusCode = 403; $ctx.Response.Close(); continue
        }

        if (Test-Path $full -PathType Leaf) {
            $ext = [System.IO.Path]::GetExtension($full).ToLower()
            $ctx.Response.ContentType = if ($types.ContainsKey($ext)) { $types[$ext] } else { "application/octet-stream" }
            # never cache the shell, so an updated index.html is picked up at once
            $ctx.Response.Headers.Add("Cache-Control", "no-store, must-revalidate")
            $bytes = [System.IO.File]::ReadAllBytes($full)
            $ctx.Response.ContentLength64 = $bytes.Length
            $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $ctx.Response.StatusCode = 404
        }
        $ctx.Response.Close()
    } catch {
        # a closed browser window can abort a request mid-flight; keep serving
    }
}
